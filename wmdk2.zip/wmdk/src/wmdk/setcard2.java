/*
 * setcard2.java
 *
 * Created on __DATE__, __TIME__
 */

package wmdk;

/**
 *
 * @author  __USER__
 */
public class setcard2 extends javax.swing.JFrame {

	/** Creates new form setcard2 */
	public setcard2() {
		initComponents();
	}

	//GEN-BEGIN:initComponents
	// <editor-fold defaultstate="collapsed" desc="Generated Code">
	private void initComponents() {

		jPanel1 = new javax.swing.JPanel();
		jPanel2 = new javax.swing.JPanel();
		jButton1 = new javax.swing.JButton();
		jLabel1 = new javax.swing.JLabel();
		jLabel2 = new javax.swing.JLabel();
		jRadioButton1 = new javax.swing.JRadioButton();
		jRadioButton2 = new javax.swing.JRadioButton();
		jRadioButton3 = new javax.swing.JRadioButton();
		jRadioButton4 = new javax.swing.JRadioButton();
		jRadioButton5 = new javax.swing.JRadioButton();
		jRadioButton6 = new javax.swing.JRadioButton();
		jRadioButton7 = new javax.swing.JRadioButton();
		jRadioButton8 = new javax.swing.JRadioButton();
		jRadioButton9 = new javax.swing.JRadioButton();
		jLabel3 = new javax.swing.JLabel();
		jLabel4 = new javax.swing.JLabel();
		jTextField1 = new javax.swing.JTextField();
		jLabel5 = new javax.swing.JLabel();
		jLabel6 = new javax.swing.JLabel();
		jTextField2 = new javax.swing.JTextField();
		jLabel7 = new javax.swing.JLabel();
		jTextField3 = new javax.swing.JTextField();
		jLabel8 = new javax.swing.JLabel();
		jRadioButton10 = new javax.swing.JRadioButton();
		jRadioButton11 = new javax.swing.JRadioButton();
		jRadioButton12 = new javax.swing.JRadioButton();
		jLabel9 = new javax.swing.JLabel();
		jRadioButton13 = new javax.swing.JRadioButton();
		jRadioButton14 = new javax.swing.JRadioButton();
		jRadioButton15 = new javax.swing.JRadioButton();
		jLabel10 = new javax.swing.JLabel();
		jTextField4 = new javax.swing.JTextField();
		jButton2 = new javax.swing.JButton();
		jButton3 = new javax.swing.JButton();

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

		jPanel1.setBackground(new java.awt.Color(255, 255, 255));

		jPanel2.setBackground(new java.awt.Color(237, 220, 215));

		jButton1.setBackground(new java.awt.Color(237, 220, 215));
		jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/dd_nav_back_nor_2x.png"))); // NOI18N
		jButton1.setBorder(null);
		jButton1.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton1ActionPerformed(evt);
			}
		});

		javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(
				jPanel2);
		jPanel2.setLayout(jPanel2Layout);
		jPanel2Layout.setHorizontalGroup(jPanel2Layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addGroup(
				jPanel2Layout.createSequentialGroup().addGap(23, 23, 23)
						.addComponent(jButton1).addContainerGap(425,
								Short.MAX_VALUE)));
		jPanel2Layout.setVerticalGroup(jPanel2Layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addGroup(
				jPanel2Layout.createSequentialGroup().addContainerGap()
						.addComponent(jButton1).addContainerGap(
								javax.swing.GroupLayout.DEFAULT_SIZE,
								Short.MAX_VALUE)));

		jLabel1.setFont(new java.awt.Font("Microsoft YaHei UI", 1, 36));
		jLabel1.setForeground(new java.awt.Color(51, 51, 51));
		jLabel1.setText("\u589e\u52a0\u6253\u5361\u4fe1\u606f");

		jLabel2.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 20));
		jLabel2.setForeground(new java.awt.Color(51, 51, 51));
		jLabel2.setText("\u661f\u671f\u6253\u5361\uff1a");

		jRadioButton1.setText("\u661f\u671f\u4e00");

		jRadioButton2.setText("\u661f\u671f\u4e8c");

		jRadioButton3.setText("\u661f\u671f\u4e09");

		jRadioButton4.setText("\u661f\u671f\u56db");

		jRadioButton5.setText("\u661f\u671f\u4e94");

		jRadioButton6.setText("\u661f\u671f\u516d");

		jRadioButton7.setText("\u661f\u671f\u65e5");

		jRadioButton8.setText("\u6bcf\u5929");

		jRadioButton9.setText("\u5355\u6b21");

		jLabel3.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 20));
		jLabel3.setForeground(new java.awt.Color(51, 51, 51));
		jLabel3.setText("\u661f\u671f\u6253\u5361\u9891\u7387\uff1a");

		jLabel4.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 20));
		jLabel4.setForeground(new java.awt.Color(51, 51, 51));
		jLabel4.setText("\u65e5\u671f\u6253\u5361\uff1a");

		jLabel5.setText("\u5e74\uff1a");

		jLabel6.setText("\u6708\uff1a");

		jLabel7.setText("\u65e5\uff1a");

		jLabel8.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 20));
		jLabel8.setForeground(new java.awt.Color(51, 51, 51));
		jLabel8.setText("\u6253\u5361\u90e8\u95e8\uff1a");

		jRadioButton10.setText("\u5de5\u7a0b\u90e8");

		jRadioButton11.setText("\u751f\u4ea7\u90e8");

		jRadioButton12.setText("\u4e1a\u52a1\u90e8");

		jLabel9.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 20));
		jLabel9.setForeground(new java.awt.Color(51, 51, 51));
		jLabel9.setText("\u6253\u5361\u5730\u70b9\uff1a");

		jRadioButton13.setText("\u516c\u53f8");

		jRadioButton14.setText("\u516c\u53f82");

		jRadioButton15.setText("\u516c\u53f83");

		jLabel10.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 20));
		jLabel10.setForeground(new java.awt.Color(51, 51, 51));
		jLabel10.setText("\u6253\u5361\u65f6\u95f4\uff1a");

		jButton2.setText("\u4fdd\u5b58");

		jButton3.setText("\u5220\u9664");

		javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(
				jPanel1);
		jPanel1.setLayout(jPanel1Layout);
		jPanel1Layout
				.setHorizontalGroup(jPanel1Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel1Layout
										.createSequentialGroup()
										.addGroup(
												jPanel1Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addGroup(
																jPanel1Layout
																		.createSequentialGroup()
																		.addGap(
																				42,
																				42,
																				42)
																		.addGroup(
																				jPanel1Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.LEADING)
																						.addGroup(
																								jPanel1Layout
																										.createSequentialGroup()
																										.addComponent(
																												jRadioButton1)
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
																										.addComponent(
																												jRadioButton2)
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
																										.addComponent(
																												jRadioButton3)
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
																										.addComponent(
																												jRadioButton4))
																						.addComponent(
																								jLabel2)
																						.addComponent(
																								jLabel3)
																						.addGroup(
																								jPanel1Layout
																										.createSequentialGroup()
																										.addComponent(
																												jRadioButton9)
																										.addGap(
																												18,
																												18,
																												18)
																										.addComponent(
																												jRadioButton8))
																						.addGroup(
																								jPanel1Layout
																										.createSequentialGroup()
																										.addComponent(
																												jLabel5)
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																										.addComponent(
																												jTextField1,
																												javax.swing.GroupLayout.PREFERRED_SIZE,
																												64,
																												javax.swing.GroupLayout.PREFERRED_SIZE)
																										.addGap(
																												18,
																												18,
																												18)
																										.addComponent(
																												jLabel6)
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																										.addComponent(
																												jTextField2,
																												javax.swing.GroupLayout.PREFERRED_SIZE,
																												70,
																												javax.swing.GroupLayout.PREFERRED_SIZE)
																										.addGap(
																												18,
																												18,
																												18)
																										.addComponent(
																												jLabel7)
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																										.addComponent(
																												jTextField3,
																												javax.swing.GroupLayout.PREFERRED_SIZE,
																												74,
																												javax.swing.GroupLayout.PREFERRED_SIZE))
																						.addComponent(
																								jLabel4)
																						.addGroup(
																								jPanel1Layout
																										.createSequentialGroup()
																										.addComponent(
																												jRadioButton5)
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
																										.addComponent(
																												jRadioButton6)
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
																										.addComponent(
																												jRadioButton7))
																						.addComponent(
																								jLabel8)
																						.addGroup(
																								jPanel1Layout
																										.createSequentialGroup()
																										.addComponent(
																												jRadioButton10)
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
																										.addComponent(
																												jRadioButton11)
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
																										.addComponent(
																												jRadioButton12))
																						.addComponent(
																								jLabel9)
																						.addComponent(
																								jLabel10)
																						.addGroup(
																								jPanel1Layout
																										.createParallelGroup(
																												javax.swing.GroupLayout.Alignment.TRAILING,
																												false)
																										.addComponent(
																												jTextField4,
																												javax.swing.GroupLayout.Alignment.LEADING)
																										.addGroup(
																												javax.swing.GroupLayout.Alignment.LEADING,
																												jPanel1Layout
																														.createSequentialGroup()
																														.addComponent(
																																jRadioButton13)
																														.addPreferredGap(
																																javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
																														.addComponent(
																																jRadioButton14)
																														.addPreferredGap(
																																javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
																														.addComponent(
																																jRadioButton15))
																										.addGroup(
																												javax.swing.GroupLayout.Alignment.LEADING,
																												jPanel1Layout
																														.createSequentialGroup()
																														.addComponent(
																																jButton2)
																														.addPreferredGap(
																																javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																														.addComponent(
																																jButton3)))))
														.addGroup(
																jPanel1Layout
																		.createSequentialGroup()
																		.addGap(
																				126,
																				126,
																				126)
																		.addComponent(
																				jLabel1)))
										.addContainerGap(95, Short.MAX_VALUE))
						.addComponent(jPanel2,
								javax.swing.GroupLayout.DEFAULT_SIZE,
								javax.swing.GroupLayout.DEFAULT_SIZE,
								Short.MAX_VALUE));
		jPanel1Layout
				.setVerticalGroup(jPanel1Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel1Layout
										.createSequentialGroup()
										.addComponent(
												jPanel2,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												65,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addGap(56, 56, 56)
										.addComponent(jLabel1)
										.addGap(62, 62, 62)
										.addComponent(jLabel2)
										.addGap(18, 18, 18)
										.addGroup(
												jPanel1Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(
																jRadioButton1)
														.addComponent(
																jRadioButton2)
														.addComponent(
																jRadioButton3)
														.addComponent(
																jRadioButton4))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
										.addGroup(
												jPanel1Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(
																jRadioButton5)
														.addComponent(
																jRadioButton6)
														.addComponent(
																jRadioButton7))
										.addGap(28, 28, 28)
										.addComponent(jLabel3)
										.addGap(18, 18, 18)
										.addGroup(
												jPanel1Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(
																jRadioButton9)
														.addComponent(
																jRadioButton8))
										.addGap(32, 32, 32)
										.addComponent(jLabel4)
										.addGap(18, 18, 18)
										.addGroup(
												jPanel1Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(jLabel5)
														.addComponent(jLabel6)
														.addComponent(
																jTextField1,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(
																jTextField2,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE)
														.addComponent(jLabel7)
														.addComponent(
																jTextField3,
																javax.swing.GroupLayout.PREFERRED_SIZE,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																javax.swing.GroupLayout.PREFERRED_SIZE))
										.addGap(35, 35, 35)
										.addComponent(jLabel8)
										.addGap(18, 18, 18)
										.addGroup(
												jPanel1Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(
																jRadioButton10)
														.addComponent(
																jRadioButton11)
														.addComponent(
																jRadioButton12))
										.addGap(27, 27, 27)
										.addComponent(jLabel9)
										.addGap(18, 18, 18)
										.addGroup(
												jPanel1Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(
																jRadioButton13)
														.addComponent(
																jRadioButton14)
														.addComponent(
																jRadioButton15))
										.addGap(31, 31, 31)
										.addComponent(jLabel10)
										.addGap(18, 18, 18)
										.addComponent(
												jTextField4,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED,
												65, Short.MAX_VALUE)
										.addGroup(
												jPanel1Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.BASELINE)
														.addComponent(jButton2)
														.addComponent(jButton3))
										.addGap(49, 49, 49)));

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(
				getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE,
				javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));
		layout.setVerticalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE,
				javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));

		pack();
	}// </editor-fold>
	//GEN-END:initComponents

	private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {
		new setcard().setVisible(true);
		this.dispose();
	}

	/**
	 * @param args the command line arguments
	 */
	public static void main(String args[]) {
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				new setcard2().setVisible(true);
			}
		});
	}

	//GEN-BEGIN:variables
	// Variables declaration - do not modify
	private javax.swing.JButton jButton1;
	private javax.swing.JButton jButton2;
	private javax.swing.JButton jButton3;
	private javax.swing.JLabel jLabel1;
	private javax.swing.JLabel jLabel10;
	private javax.swing.JLabel jLabel2;
	private javax.swing.JLabel jLabel3;
	private javax.swing.JLabel jLabel4;
	private javax.swing.JLabel jLabel5;
	private javax.swing.JLabel jLabel6;
	private javax.swing.JLabel jLabel7;
	private javax.swing.JLabel jLabel8;
	private javax.swing.JLabel jLabel9;
	private javax.swing.JPanel jPanel1;
	private javax.swing.JPanel jPanel2;
	private javax.swing.JRadioButton jRadioButton1;
	private javax.swing.JRadioButton jRadioButton10;
	private javax.swing.JRadioButton jRadioButton11;
	private javax.swing.JRadioButton jRadioButton12;
	private javax.swing.JRadioButton jRadioButton13;
	private javax.swing.JRadioButton jRadioButton14;
	private javax.swing.JRadioButton jRadioButton15;
	private javax.swing.JRadioButton jRadioButton2;
	private javax.swing.JRadioButton jRadioButton3;
	private javax.swing.JRadioButton jRadioButton4;
	private javax.swing.JRadioButton jRadioButton5;
	private javax.swing.JRadioButton jRadioButton6;
	private javax.swing.JRadioButton jRadioButton7;
	private javax.swing.JRadioButton jRadioButton8;
	private javax.swing.JRadioButton jRadioButton9;
	private javax.swing.JTextField jTextField1;
	private javax.swing.JTextField jTextField2;
	private javax.swing.JTextField jTextField3;
	private javax.swing.JTextField jTextField4;
	// End of variables declaration//GEN-END:variables

}