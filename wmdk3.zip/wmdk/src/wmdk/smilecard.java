/*
 * smilecard.java
 *
 * Created on __DATE__, __TIME__
 */

package wmdk;

/**
 *
 * @author  __USER__
 */
public class smilecard extends javax.swing.JFrame {

	/** Creates new form smilecard */
	public smilecard() {
		initComponents();
	}

	//GEN-BEGIN:initComponents
	// <editor-fold defaultstate="collapsed" desc="Generated Code">
	private void initComponents() {

		jPanel3 = new javax.swing.JPanel();
		jPanel4 = new javax.swing.JPanel();
		jButton10 = new javax.swing.JButton();
		jButton11 = new javax.swing.JButton();
		jButton12 = new javax.swing.JButton();
		jLabel1 = new javax.swing.JLabel();
		jButton13 = new javax.swing.JButton();

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

		jPanel3.setBackground(new java.awt.Color(237, 220, 215));

		jPanel4.setBackground(new java.awt.Color(143, 127, 121));

		jButton10.setBackground(new java.awt.Color(143, 127, 121));
		jButton10.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/photo.png"))); // NOI18N
		jButton10.setBorder(null);

		jButton11.setBackground(new java.awt.Color(143, 127, 121));
		jButton11.setFont(new java.awt.Font("����", 1, 24));
		jButton11.setForeground(new java.awt.Color(255, 255, 255));
		jButton11.setText("\u91cd\u62cd");
		jButton11.setBorder(null);

		jButton12.setBackground(new java.awt.Color(143, 127, 121));
		jButton12.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/zhishu.png"))); // NOI18N
		jButton12.setBorder(null);

		jLabel1.setFont(new java.awt.Font("Microsoft YaHei UI", 1, 24));
		jLabel1.setForeground(new java.awt.Color(255, 255, 255));
		jLabel1.setText("88");

		jButton13.setBackground(new java.awt.Color(143, 127, 121));
		jButton13.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/dd_nav_back_nor_2x.png"))); // NOI18N
		jButton13.setBorder(null);
		jButton13.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton13ActionPerformed(evt);
			}
		});

		javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(
				jPanel4);
		jPanel4.setLayout(jPanel4Layout);
		jPanel4Layout.setHorizontalGroup(jPanel4Layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addGroup(
				jPanel4Layout.createSequentialGroup().addGroup(
						jPanel4Layout.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
								.addGroup(
										jPanel4Layout.createSequentialGroup()
												.addGap(56, 56, 56)
												.addComponent(jButton11)
												.addGap(66, 66, 66)
												.addComponent(jButton10)
												.addGap(57, 57, 57)
												.addComponent(jButton12)
												.addGap(18, 18, 18)
												.addComponent(jLabel1))
								.addGroup(
										jPanel4Layout.createSequentialGroup()
												.addContainerGap()
												.addComponent(jButton13)))
						.addContainerGap(49, Short.MAX_VALUE)));
		jPanel4Layout
				.setVerticalGroup(jPanel4Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								javax.swing.GroupLayout.Alignment.TRAILING,
								jPanel4Layout
										.createSequentialGroup()
										.addContainerGap()
										.addComponent(jButton13)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED,
												612, Short.MAX_VALUE)
										.addGroup(
												jPanel4Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addGroup(
																javax.swing.GroupLayout.Alignment.TRAILING,
																jPanel4Layout
																		.createSequentialGroup()
																		.addComponent(
																				jButton11)
																		.addGap(
																				44,
																				44,
																				44))
														.addGroup(
																javax.swing.GroupLayout.Alignment.TRAILING,
																jPanel4Layout
																		.createSequentialGroup()
																		.addComponent(
																				jButton10)
																		.addGap(
																				31,
																				31,
																				31))
														.addGroup(
																javax.swing.GroupLayout.Alignment.TRAILING,
																jPanel4Layout
																		.createSequentialGroup()
																		.addGroup(
																				jPanel4Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.TRAILING)
																						.addComponent(
																								jLabel1)
																						.addComponent(
																								jButton12))
																		.addGap(
																				46,
																				46,
																				46)))));

		javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(
				jPanel3);
		jPanel3.setLayout(jPanel3Layout);
		jPanel3Layout.setHorizontalGroup(jPanel3Layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addGroup(
				jPanel3Layout.createSequentialGroup().addContainerGap()
						.addComponent(jPanel4,
								javax.swing.GroupLayout.DEFAULT_SIZE,
								javax.swing.GroupLayout.DEFAULT_SIZE,
								Short.MAX_VALUE).addContainerGap()));
		jPanel3Layout.setVerticalGroup(jPanel3Layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addGroup(
				javax.swing.GroupLayout.Alignment.TRAILING,
				jPanel3Layout.createSequentialGroup().addContainerGap()
						.addComponent(jPanel4,
								javax.swing.GroupLayout.DEFAULT_SIZE,
								javax.swing.GroupLayout.DEFAULT_SIZE,
								Short.MAX_VALUE)));

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(
				getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE,
				javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));
		layout.setVerticalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE,
				javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));

		pack();
	}// </editor-fold>
	//GEN-END:initComponents

	private void jButton13ActionPerformed(java.awt.event.ActionEvent evt) {
		new homepage().setVisible(true);
		this.dispose();
	}

	/**
	 * @param args the command line arguments
	 */
	public static void main(String args[]) {
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				new smilecard().setVisible(true);
			}
		});
	}

	//GEN-BEGIN:variables
	// Variables declaration - do not modify
	private javax.swing.JButton jButton1;
	private javax.swing.JButton jButton10;
	private javax.swing.JButton jButton11;
	private javax.swing.JButton jButton12;
	private javax.swing.JButton jButton13;
	private javax.swing.JButton jButton2;
	private javax.swing.JButton jButton3;
	private javax.swing.JButton jButton4;
	private javax.swing.JButton jButton5;
	private javax.swing.JButton jButton6;
	private javax.swing.JButton jButton7;
	private javax.swing.JButton jButton8;
	private javax.swing.JButton jButton9;
	private javax.swing.JLabel jLabel1;
	private javax.swing.JPanel jPanel1;
	private javax.swing.JPanel jPanel2;
	private javax.swing.JPanel jPanel3;
	private javax.swing.JPanel jPanel4;
	// End of variables declaration//GEN-END:variables

}