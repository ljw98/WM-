/*
 * history.java
 *
 * Created on __DATE__, __TIME__
 */

package wmdk;

import java.util.Calendar;

import javax.swing.JButton;

/**
 *
 * @author  __USER__
 */
public class history extends javax.swing.JFrame {

	/** Creates new form history */
	public history() {
		initComponents();
		JButton[] buttons = { this.jButton6, this.jButton7, this.jButton8,
				this.jButton9, this.jButton10, this.jButton11, this.jButton12,
				this.jButton13, this.jButton14, this.jButton15, this.jButton16,
				this.jButton17, this.jButton18, this.jButton19, this.jButton20,
				this.jButton21, this.jButton22, this.jButton23, this.jButton24,
				this.jButton25, this.jButton26, this.jButton27, this.jButton28,
				this.jButton29, this.jButton30, this.jButton31, this.jButton32,
				this.jButton33, this.jButton34, this.jButton35, this.jButton36,
				this.jButton37, this.jButton38, this.jButton39, this.jButton40,
				this.jButton41, this.jButton42, this.jButton43, this.jButton44,
				this.jButton45, this.jButton46, this.jButton47, };
		
		

		Calendar c = Calendar.getInstance();
		int year = c.get(Calendar.YEAR);
		int month = c.get(Calendar.MONTH);
	    int weekday = c.get(Calendar.DAY_OF_WEEK);		
		int days=c.getActualMaximum(Calendar.DAY_OF_MONTH);
		this.jLabel30.setText(year + "�� " + (month + 1) + "��");
		
         int start = 7 - weekday;
		//�������һ��
	      int currentMonth = month;
	     c.set(c.get(Calendar.YEAR), currentMonth, 1);
	     c.add(Calendar.DATE, -1);
	     int nextmonth = c.get(Calendar.DAY_OF_MONTH);
	   
		LoadDay(buttons, nextmonth-start+1, start, days+1);
	}
//������ȡ��һ����Щ����
	

	void LoadDay(JButton[] buttons, int start, int gap, int days) {
		int i = 0;
		for (; i < 42 && i < gap; i++) {
			//			System.out.println(i);
			buttons[i].setText(start + i + "");
			buttons[i].setEnabled(false);
		}
		for (int j = 1; i < 42 && j < days; i++, j++) {
			buttons[i].setText(j + "");

		}
		for (int j = 1; i < 42; i++, j++) {
			buttons[i].setText(j + "");
			buttons[i].setEnabled(false);
		}
	}

	//GEN-BEGIN:initComponents
	// <editor-fold defaultstate="collapsed" desc="Generated Code">
	private void initComponents() {

		jPanel1 = new javax.swing.JPanel();
		jButton1 = new javax.swing.JButton();
		jPanel2 = new javax.swing.JPanel();
		jLabel12 = new javax.swing.JLabel();
		canvas1 = new java.awt.Canvas();
		jLabel1 = new javax.swing.JLabel();
		jLabel13 = new javax.swing.JLabel();
		jLabel14 = new javax.swing.JLabel();
		jLabel15 = new javax.swing.JLabel();
		jLabel16 = new javax.swing.JLabel();
		jLabel17 = new javax.swing.JLabel();
		jButton6 = new javax.swing.JButton();
		jButton7 = new javax.swing.JButton();
		jButton8 = new javax.swing.JButton();
		jButton9 = new javax.swing.JButton();
		jButton10 = new javax.swing.JButton();
		jButton11 = new javax.swing.JButton();
		jButton12 = new javax.swing.JButton();
		jButton13 = new javax.swing.JButton();
		jButton14 = new javax.swing.JButton();
		jButton15 = new javax.swing.JButton();
		jButton16 = new javax.swing.JButton();
		jButton17 = new javax.swing.JButton();
		jButton18 = new javax.swing.JButton();
		jButton19 = new javax.swing.JButton();
		jButton20 = new javax.swing.JButton();
		jButton21 = new javax.swing.JButton();
		jButton22 = new javax.swing.JButton();
		jButton23 = new javax.swing.JButton();
		jButton24 = new javax.swing.JButton();
		jButton25 = new javax.swing.JButton();
		jButton26 = new javax.swing.JButton();
		jButton27 = new javax.swing.JButton();
		jButton28 = new javax.swing.JButton();
		jButton29 = new javax.swing.JButton();
		jButton30 = new javax.swing.JButton();
		jButton31 = new javax.swing.JButton();
		jButton32 = new javax.swing.JButton();
		jButton33 = new javax.swing.JButton();
		jButton34 = new javax.swing.JButton();
		jButton35 = new javax.swing.JButton();
		jButton36 = new javax.swing.JButton();
		jButton37 = new javax.swing.JButton();
		jButton38 = new javax.swing.JButton();
		jButton39 = new javax.swing.JButton();
		jButton40 = new javax.swing.JButton();
		jButton41 = new javax.swing.JButton();
		jButton42 = new javax.swing.JButton();
		jButton43 = new javax.swing.JButton();
		jButton44 = new javax.swing.JButton();
		jButton45 = new javax.swing.JButton();
		jButton46 = new javax.swing.JButton();
		jButton47 = new javax.swing.JButton();
		jLabel18 = new javax.swing.JLabel();
		jLabel30 = new javax.swing.JLabel();
		jPanel4 = new javax.swing.JPanel();
		jLabel4 = new javax.swing.JLabel();
		jButton48 = new javax.swing.JButton();
		jLabel20 = new javax.swing.JLabel();
		jButton49 = new javax.swing.JButton();
		jLabel22 = new javax.swing.JLabel();
		jButton50 = new javax.swing.JButton();
		jLabel5 = new javax.swing.JLabel();
		jButton51 = new javax.swing.JButton();
		jLabel25 = new javax.swing.JLabel();
		jButton52 = new javax.swing.JButton();
		jButton53 = new javax.swing.JButton();
		jLabel6 = new javax.swing.JLabel();

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

		jPanel1.setBackground(new java.awt.Color(237, 220, 215));

		jButton1.setBackground(new java.awt.Color(237, 220, 215));
		jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/dd_nav_back_nor_2x.png"))); // NOI18N
		jButton1.setBorder(null);
		jButton1.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton1ActionPerformed(evt);
			}
		});

		jPanel2.setBackground(new java.awt.Color(255, 255, 255));

		jLabel12.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 24));
		jLabel12.setForeground(new java.awt.Color(51, 51, 51));
		jLabel12.setText("\u5386\u53f2\u7edf\u8ba1\u3010\u65e5\u3011");

		jLabel1.setFont(new java.awt.Font("Microsoft YaHei UI", 1, 18));
		jLabel1.setForeground(new java.awt.Color(51, 51, 51));
		jLabel1.setText("\u65e5");

		jLabel13.setFont(new java.awt.Font("Microsoft YaHei UI", 1, 18));
		jLabel13.setForeground(new java.awt.Color(51, 51, 51));
		jLabel13.setText("\u4e00");

		jLabel14.setFont(new java.awt.Font("Microsoft YaHei UI", 1, 18));
		jLabel14.setForeground(new java.awt.Color(51, 51, 51));
		jLabel14.setText("\u4e8c");

		jLabel15.setFont(new java.awt.Font("Microsoft YaHei UI", 1, 18));
		jLabel15.setForeground(new java.awt.Color(51, 51, 51));
		jLabel15.setText("\u4e09");

		jLabel16.setFont(new java.awt.Font("Microsoft YaHei UI", 1, 18));
		jLabel16.setForeground(new java.awt.Color(51, 51, 51));
		jLabel16.setText("\u56db");

		jLabel17.setFont(new java.awt.Font("Microsoft YaHei UI", 1, 18));
		jLabel17.setForeground(new java.awt.Color(51, 51, 51));
		jLabel17.setText("\u4e94");

		jButton6.setBackground(new java.awt.Color(255, 255, 255));
		jButton6.setText("jButton6");

		jButton7.setBackground(new java.awt.Color(255, 255, 255));
		jButton7.setText("jButton6");

		jButton8.setBackground(new java.awt.Color(255, 255, 255));
		jButton8.setText("jButton6");

		jButton9.setBackground(new java.awt.Color(255, 255, 255));
		jButton9.setText("jButton6");

		jButton10.setBackground(new java.awt.Color(255, 255, 255));
		jButton10.setText("jButton6");

		jButton11.setBackground(new java.awt.Color(255, 255, 255));
		jButton11.setText("jButton6");

		jButton12.setBackground(new java.awt.Color(255, 255, 255));
		jButton12.setText("jButton6");

		jButton13.setBackground(new java.awt.Color(255, 255, 255));
		jButton13.setText("jButton6");

		jButton14.setBackground(new java.awt.Color(255, 255, 255));
		jButton14.setText("jButton6");

		jButton15.setBackground(new java.awt.Color(255, 255, 255));
		jButton15.setText("jButton6");

		jButton16.setBackground(new java.awt.Color(255, 255, 255));
		jButton16.setText("jButton6");

		jButton17.setBackground(new java.awt.Color(255, 255, 255));
		jButton17.setText("jButton6");

		jButton18.setBackground(new java.awt.Color(255, 255, 255));
		jButton18.setText("jButton6");

		jButton19.setBackground(new java.awt.Color(255, 255, 255));
		jButton19.setText("jButton6");

		jButton20.setBackground(new java.awt.Color(255, 255, 255));
		jButton20.setText("jButton6");

		jButton21.setBackground(new java.awt.Color(255, 255, 255));
		jButton21.setText("jButton6");

		jButton22.setBackground(new java.awt.Color(255, 255, 255));
		jButton22.setText("jButton6");

		jButton23.setBackground(new java.awt.Color(255, 255, 255));
		jButton23.setText("jButton6");

		jButton24.setBackground(new java.awt.Color(255, 255, 255));
		jButton24.setText("jButton6");

		jButton25.setBackground(new java.awt.Color(255, 255, 255));
		jButton25.setText("jButton6");

		jButton26.setBackground(new java.awt.Color(255, 255, 255));
		jButton26.setText("jButton6");

		jButton27.setBackground(new java.awt.Color(255, 255, 255));
		jButton27.setText("jButton6");

		jButton28.setBackground(new java.awt.Color(255, 255, 255));
		jButton28.setText("jButton6");

		jButton29.setBackground(new java.awt.Color(255, 255, 255));
		jButton29.setText("jButton6");

		jButton30.setBackground(new java.awt.Color(255, 255, 255));
		jButton30.setText("jButton6");

		jButton31.setBackground(new java.awt.Color(255, 255, 255));
		jButton31.setText("jButton6");

		jButton32.setBackground(new java.awt.Color(255, 255, 255));
		jButton32.setText("jButton6");

		jButton33.setBackground(new java.awt.Color(255, 255, 255));
		jButton33.setText("jButton6");

		jButton34.setBackground(new java.awt.Color(255, 255, 255));
		jButton34.setText("jButton6");

		jButton35.setBackground(new java.awt.Color(255, 255, 255));
		jButton35.setText("jButton6");

		jButton36.setBackground(new java.awt.Color(255, 255, 255));
		jButton36.setText("jButton6");

		jButton37.setBackground(new java.awt.Color(255, 255, 255));
		jButton37.setText("jButton6");

		jButton38.setBackground(new java.awt.Color(255, 255, 255));
		jButton38.setText("jButton6");

		jButton39.setBackground(new java.awt.Color(255, 255, 255));
		jButton39.setText("jButton6");

		jButton40.setBackground(new java.awt.Color(255, 255, 255));
		jButton40.setText("jButton6");

		jButton41.setBackground(new java.awt.Color(255, 255, 255));
		jButton41.setText("jButton6");

		jButton42.setBackground(new java.awt.Color(255, 255, 255));
		jButton42.setText("jButton6");

		jButton43.setBackground(new java.awt.Color(255, 255, 255));
		jButton43.setText("jButton6");

		jButton44.setBackground(new java.awt.Color(255, 255, 255));
		jButton44.setText("jButton6");

		jButton45.setBackground(new java.awt.Color(255, 255, 255));
		jButton45.setText("jButton6");

		jButton46.setBackground(new java.awt.Color(255, 255, 255));
		jButton46.setText("jButton6");

		jButton47.setBackground(new java.awt.Color(255, 255, 255));
		jButton47.setText("jButton6");

		jLabel18.setFont(new java.awt.Font("Microsoft YaHei UI", 1, 18));
		jLabel18.setForeground(new java.awt.Color(51, 51, 51));
		jLabel18.setText("\u516d");

		jLabel30.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 24));
		jLabel30.setForeground(new java.awt.Color(51, 51, 51));
		jLabel30.setText("2018\u5e7412\u6708");

		javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(
				jPanel2);
		jPanel2.setLayout(jPanel2Layout);
		jPanel2Layout
				.setHorizontalGroup(jPanel2Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel2Layout
										.createSequentialGroup()
										.addContainerGap()
										.addGroup(
												jPanel2Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addGroup(
																jPanel2Layout
																		.createSequentialGroup()
																		.addComponent(
																				jButton20,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				61,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jButton21,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				61,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jButton22,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				61,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jButton23,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				61,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jButton24,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				61,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jButton25,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				61,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jButton26,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				61,
																				javax.swing.GroupLayout.PREFERRED_SIZE))
														.addGroup(
																jPanel2Layout
																		.createSequentialGroup()
																		.addComponent(
																				jButton27,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				61,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jButton28,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				61,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jButton29,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				61,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jButton30,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				61,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jButton31,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				61,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jButton32,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				61,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jButton33,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				61,
																				javax.swing.GroupLayout.PREFERRED_SIZE))
														.addGroup(
																jPanel2Layout
																		.createSequentialGroup()
																		.addComponent(
																				jButton34,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				61,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jButton35,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				61,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jButton36,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				61,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jButton37,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				61,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jButton38,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				61,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jButton39,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				61,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jButton40,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				61,
																				javax.swing.GroupLayout.PREFERRED_SIZE))
														.addGroup(
																jPanel2Layout
																		.createSequentialGroup()
																		.addComponent(
																				jButton41,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				61,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jButton42,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				61,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jButton43,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				61,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jButton44,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				61,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jButton45,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				61,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jButton46,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				61,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jButton47,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				61,
																				javax.swing.GroupLayout.PREFERRED_SIZE))
														.addGroup(
																jPanel2Layout
																		.createParallelGroup(
																				javax.swing.GroupLayout.Alignment.TRAILING,
																				false)
																		.addGroup(
																				javax.swing.GroupLayout.Alignment.LEADING,
																				jPanel2Layout
																						.createSequentialGroup()
																						.addComponent(
																								jButton6,
																								javax.swing.GroupLayout.PREFERRED_SIZE,
																								61,
																								javax.swing.GroupLayout.PREFERRED_SIZE)
																						.addPreferredGap(
																								javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																						.addComponent(
																								jButton7,
																								javax.swing.GroupLayout.PREFERRED_SIZE,
																								61,
																								javax.swing.GroupLayout.PREFERRED_SIZE)
																						.addPreferredGap(
																								javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																						.addComponent(
																								jButton8,
																								javax.swing.GroupLayout.PREFERRED_SIZE,
																								61,
																								javax.swing.GroupLayout.PREFERRED_SIZE)
																						.addPreferredGap(
																								javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																						.addComponent(
																								jButton9,
																								javax.swing.GroupLayout.PREFERRED_SIZE,
																								61,
																								javax.swing.GroupLayout.PREFERRED_SIZE)
																						.addPreferredGap(
																								javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																						.addComponent(
																								jButton10,
																								javax.swing.GroupLayout.PREFERRED_SIZE,
																								61,
																								javax.swing.GroupLayout.PREFERRED_SIZE)
																						.addPreferredGap(
																								javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																						.addComponent(
																								jButton11,
																								javax.swing.GroupLayout.PREFERRED_SIZE,
																								61,
																								javax.swing.GroupLayout.PREFERRED_SIZE)
																						.addPreferredGap(
																								javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																						.addComponent(
																								jButton12,
																								0,
																								0,
																								Short.MAX_VALUE))
																		.addGroup(
																				javax.swing.GroupLayout.Alignment.LEADING,
																				jPanel2Layout
																						.createSequentialGroup()
																						.addComponent(
																								jButton13,
																								javax.swing.GroupLayout.PREFERRED_SIZE,
																								61,
																								javax.swing.GroupLayout.PREFERRED_SIZE)
																						.addPreferredGap(
																								javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																						.addComponent(
																								jButton14,
																								javax.swing.GroupLayout.PREFERRED_SIZE,
																								61,
																								javax.swing.GroupLayout.PREFERRED_SIZE)
																						.addPreferredGap(
																								javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																						.addComponent(
																								jButton15,
																								javax.swing.GroupLayout.PREFERRED_SIZE,
																								61,
																								javax.swing.GroupLayout.PREFERRED_SIZE)
																						.addPreferredGap(
																								javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																						.addComponent(
																								jButton16,
																								javax.swing.GroupLayout.PREFERRED_SIZE,
																								61,
																								javax.swing.GroupLayout.PREFERRED_SIZE)
																						.addPreferredGap(
																								javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																						.addComponent(
																								jButton17,
																								javax.swing.GroupLayout.PREFERRED_SIZE,
																								61,
																								javax.swing.GroupLayout.PREFERRED_SIZE)
																						.addPreferredGap(
																								javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																						.addComponent(
																								jButton18,
																								javax.swing.GroupLayout.PREFERRED_SIZE,
																								61,
																								javax.swing.GroupLayout.PREFERRED_SIZE)
																						.addPreferredGap(
																								javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																						.addComponent(
																								jButton19,
																								javax.swing.GroupLayout.PREFERRED_SIZE,
																								61,
																								javax.swing.GroupLayout.PREFERRED_SIZE)))
														.addGroup(
																jPanel2Layout
																		.createSequentialGroup()
																		.addGap(
																				19,
																				19,
																				19)
																		.addGroup(
																				jPanel2Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.TRAILING)
																						.addGroup(
																								jPanel2Layout
																										.createSequentialGroup()
																										.addComponent(
																												jLabel1)
																										.addGap(
																												55,
																												55,
																												55)
																										.addComponent(
																												jLabel13)
																										.addGap(
																												54,
																												54,
																												54)
																										.addComponent(
																												jLabel14)
																										.addGap(
																												52,
																												52,
																												52)
																										.addComponent(
																												jLabel15)
																										.addGap(
																												53,
																												53,
																												53)
																										.addComponent(
																												jLabel16))
																						.addGroup(
																								jPanel2Layout
																										.createParallelGroup(
																												javax.swing.GroupLayout.Alignment.LEADING)
																										.addGroup(
																												jPanel2Layout
																														.createSequentialGroup()
																														.addGap(
																																10,
																																10,
																																10)
																														.addComponent(
																																jLabel30))
																										.addComponent(
																												jLabel12)))
																		.addGap(
																				44,
																				44,
																				44)
																		.addComponent(
																				jLabel17)
																		.addGap(
																				58,
																				58,
																				58)
																		.addComponent(
																				jLabel18)))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												Short.MAX_VALUE)
										.addComponent(
												canvas1,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												17,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addContainerGap()));
		jPanel2Layout
				.setVerticalGroup(jPanel2Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel2Layout
										.createSequentialGroup()
										.addGroup(
												jPanel2Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addGroup(
																jPanel2Layout
																		.createSequentialGroup()
																		.addContainerGap()
																		.addComponent(
																				jLabel12)
																		.addGap(
																				13,
																				13,
																				13)
																		.addGroup(
																				jPanel2Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.LEADING)
																						.addGroup(
																								jPanel2Layout
																										.createSequentialGroup()
																										.addGap(
																												265,
																												265,
																												265)
																										.addComponent(
																												canvas1,
																												javax.swing.GroupLayout.PREFERRED_SIZE,
																												javax.swing.GroupLayout.DEFAULT_SIZE,
																												javax.swing.GroupLayout.PREFERRED_SIZE))
																						.addGroup(
																								jPanel2Layout
																										.createSequentialGroup()
																										.addGap(
																												50,
																												50,
																												50)
																										.addGroup(
																												jPanel2Layout
																														.createParallelGroup(
																																javax.swing.GroupLayout.Alignment.BASELINE)
																														.addComponent(
																																jLabel1)
																														.addComponent(
																																jLabel13)
																														.addComponent(
																																jLabel14)
																														.addComponent(
																																jLabel15)
																														.addComponent(
																																jLabel16)
																														.addComponent(
																																jLabel17)
																														.addComponent(
																																jLabel18))
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																										.addGroup(
																												jPanel2Layout
																														.createParallelGroup(
																																javax.swing.GroupLayout.Alignment.BASELINE)
																														.addComponent(
																																jButton6)
																														.addComponent(
																																jButton7)
																														.addComponent(
																																jButton8)
																														.addComponent(
																																jButton9)
																														.addComponent(
																																jButton10)
																														.addComponent(
																																jButton11)
																														.addComponent(
																																jButton12))
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																										.addGroup(
																												jPanel2Layout
																														.createParallelGroup(
																																javax.swing.GroupLayout.Alignment.BASELINE)
																														.addComponent(
																																jButton13)
																														.addComponent(
																																jButton14)
																														.addComponent(
																																jButton15)
																														.addComponent(
																																jButton16)
																														.addComponent(
																																jButton17)
																														.addComponent(
																																jButton18)
																														.addComponent(
																																jButton19))
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																										.addGroup(
																												jPanel2Layout
																														.createParallelGroup(
																																javax.swing.GroupLayout.Alignment.BASELINE)
																														.addComponent(
																																jButton20)
																														.addComponent(
																																jButton21)
																														.addComponent(
																																jButton22)
																														.addComponent(
																																jButton23)
																														.addComponent(
																																jButton24)
																														.addComponent(
																																jButton25)
																														.addComponent(
																																jButton26))
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																										.addGroup(
																												jPanel2Layout
																														.createParallelGroup(
																																javax.swing.GroupLayout.Alignment.BASELINE)
																														.addComponent(
																																jButton27)
																														.addComponent(
																																jButton28)
																														.addComponent(
																																jButton29)
																														.addComponent(
																																jButton30)
																														.addComponent(
																																jButton31)
																														.addComponent(
																																jButton32)
																														.addComponent(
																																jButton33))
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																										.addGroup(
																												jPanel2Layout
																														.createParallelGroup(
																																javax.swing.GroupLayout.Alignment.BASELINE)
																														.addComponent(
																																jButton34)
																														.addComponent(
																																jButton35)
																														.addComponent(
																																jButton36)
																														.addComponent(
																																jButton37)
																														.addComponent(
																																jButton38)
																														.addComponent(
																																jButton39)
																														.addComponent(
																																jButton40))
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																										.addGroup(
																												jPanel2Layout
																														.createParallelGroup(
																																javax.swing.GroupLayout.Alignment.BASELINE)
																														.addComponent(
																																jButton41)
																														.addComponent(
																																jButton42)
																														.addComponent(
																																jButton43)
																														.addComponent(
																																jButton44)
																														.addComponent(
																																jButton45)
																														.addComponent(
																																jButton46)
																														.addComponent(
																																jButton47)))))
														.addGroup(
																jPanel2Layout
																		.createSequentialGroup()
																		.addGap(
																				57,
																				57,
																				57)
																		.addComponent(
																				jLabel30)))
										.addContainerGap(36, Short.MAX_VALUE)));

		jPanel4.setBackground(new java.awt.Color(255, 255, 255));

		jLabel4.setFont(new java.awt.Font("Microsoft YaHei UI", 1, 15));
		jLabel4.setText("05");

		jButton48.setBackground(new java.awt.Color(255, 255, 255));
		jButton48.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 16));
		jButton48.setText("\u51c6\u65f6\u4eba\u6570");
		jButton48.setBorder(null);
		jButton48.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton48ActionPerformed(evt);
			}
		});

		jLabel20.setFont(new java.awt.Font("Microsoft YaHei UI", 1, 15));
		jLabel20.setText("01");

		jButton49.setBackground(new java.awt.Color(255, 255, 255));
		jButton49.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 16));
		jButton49.setText("\u65e9\u9000\u4eba\u6570");
		jButton49.setBorder(null);

		jLabel22.setFont(new java.awt.Font("Microsoft YaHei UI", 1, 15));
		jLabel22.setText("01");

		jButton50.setBackground(new java.awt.Color(255, 255, 255));
		jButton50.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 16));
		jButton50.setText("\u8bf7\u5047\u4eba\u6570");
		jButton50.setBorder(null);

		jLabel5.setFont(new java.awt.Font("Microsoft YaHei UI", 1, 15));
		jLabel5.setText("05");

		jButton51.setBackground(new java.awt.Color(255, 255, 255));
		jButton51.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 16));
		jButton51.setText("\u8865\u5361\u4eba\u6570");
		jButton51.setBorder(null);

		jLabel25.setFont(new java.awt.Font("Microsoft YaHei UI", 1, 15));
		jLabel25.setText("01");

		jButton52.setBackground(new java.awt.Color(255, 255, 255));
		jButton52.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 16));
		jButton52.setText("\u672a\u5230\u4eba\u6570");
		jButton52.setBorder(null);

		jButton53.setBackground(new java.awt.Color(255, 255, 255));
		jButton53.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 16));
		jButton53.setText("\u8fdf\u5230\u4eba\u6570");
		jButton53.setBorder(null);

		jLabel6.setFont(new java.awt.Font("Microsoft YaHei UI", 1, 15));
		jLabel6.setText("01");

		javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(
				jPanel4);
		jPanel4.setLayout(jPanel4Layout);
		jPanel4Layout
				.setHorizontalGroup(jPanel4Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel4Layout
										.createSequentialGroup()
										.addGap(30, 30, 30)
										.addGroup(
												jPanel4Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.CENTER)
														.addComponent(
																jButton48,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																81,
																Short.MAX_VALUE)
														.addComponent(
																jButton49,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																81,
																Short.MAX_VALUE))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(
												jPanel4Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addComponent(jLabel4)
														.addComponent(jLabel20))
										.addGap(60, 60, 60)
										.addGroup(
												jPanel4Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.TRAILING)
														.addComponent(
																jButton50,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																78,
																Short.MAX_VALUE)
														.addComponent(
																jButton51,
																javax.swing.GroupLayout.Alignment.LEADING,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																78,
																Short.MAX_VALUE))
										.addGap(15, 15, 15)
										.addGroup(
												jPanel4Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addComponent(jLabel5)
														.addComponent(jLabel22))
										.addGap(29, 29, 29)
										.addGroup(
												jPanel4Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addComponent(
																jButton52,
																javax.swing.GroupLayout.Alignment.TRAILING,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																78,
																Short.MAX_VALUE)
														.addComponent(
																jButton53,
																javax.swing.GroupLayout.Alignment.TRAILING,
																javax.swing.GroupLayout.DEFAULT_SIZE,
																78,
																Short.MAX_VALUE))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(
												jPanel4Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addComponent(jLabel6)
														.addComponent(jLabel25))
										.addGap(66, 66, 66)));
		jPanel4Layout
				.setVerticalGroup(jPanel4Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel4Layout
										.createSequentialGroup()
										.addGap(71, 71, 71)
										.addGroup(
												jPanel4Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.TRAILING)
														.addGroup(
																jPanel4Layout
																		.createSequentialGroup()
																		.addGroup(
																				jPanel4Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.CENTER)
																						.addComponent(
																								jButton50,
																								javax.swing.GroupLayout.PREFERRED_SIZE,
																								29,
																								javax.swing.GroupLayout.PREFERRED_SIZE)
																						.addComponent(
																								jButton53,
																								javax.swing.GroupLayout.PREFERRED_SIZE,
																								29,
																								javax.swing.GroupLayout.PREFERRED_SIZE)
																						.addComponent(
																								jLabel5)
																						.addComponent(
																								jLabel6))
																		.addGap(
																				69,
																				69,
																				69)
																		.addGroup(
																				jPanel4Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.CENTER)
																						.addComponent(
																								jButton51,
																								javax.swing.GroupLayout.PREFERRED_SIZE,
																								29,
																								javax.swing.GroupLayout.PREFERRED_SIZE)
																						.addComponent(
																								jButton52,
																								javax.swing.GroupLayout.PREFERRED_SIZE,
																								29,
																								javax.swing.GroupLayout.PREFERRED_SIZE)
																						.addComponent(
																								jLabel22)
																						.addComponent(
																								jLabel25)))
														.addGroup(
																jPanel4Layout
																		.createSequentialGroup()
																		.addGroup(
																				jPanel4Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.BASELINE)
																						.addComponent(
																								jButton48,
																								javax.swing.GroupLayout.PREFERRED_SIZE,
																								29,
																								javax.swing.GroupLayout.PREFERRED_SIZE)
																						.addComponent(
																								jLabel4))
																		.addGap(
																				69,
																				69,
																				69)
																		.addGroup(
																				jPanel4Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.BASELINE)
																						.addComponent(
																								jButton49,
																								javax.swing.GroupLayout.PREFERRED_SIZE,
																								29,
																								javax.swing.GroupLayout.PREFERRED_SIZE)
																						.addComponent(
																								jLabel20))))
										.addContainerGap(78, Short.MAX_VALUE)));

		javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(
				jPanel1);
		jPanel1.setLayout(jPanel1Layout);
		jPanel1Layout.setHorizontalGroup(jPanel1Layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addGroup(
				jPanel1Layout.createSequentialGroup().addContainerGap()
						.addComponent(jButton1,
								javax.swing.GroupLayout.PREFERRED_SIZE, 38,
								javax.swing.GroupLayout.PREFERRED_SIZE))
				.addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE,
						503, Short.MAX_VALUE).addComponent(jPanel4,
						javax.swing.GroupLayout.DEFAULT_SIZE,
						javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));
		jPanel1Layout
				.setVerticalGroup(jPanel1Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel1Layout
										.createSequentialGroup()
										.addContainerGap(
												javax.swing.GroupLayout.DEFAULT_SIZE,
												Short.MAX_VALUE)
										.addComponent(
												jButton1,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												37,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(
												jPanel2,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addGap(18, 18, 18)
										.addComponent(
												jPanel4,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.PREFERRED_SIZE)));

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(
				getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE,
				javax.swing.GroupLayout.DEFAULT_SIZE,
				javax.swing.GroupLayout.PREFERRED_SIZE));
		layout.setVerticalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE,
				javax.swing.GroupLayout.DEFAULT_SIZE,
				javax.swing.GroupLayout.PREFERRED_SIZE));

		pack();
	}// </editor-fold>
	//GEN-END:initComponents

	private void jButton48ActionPerformed(java.awt.event.ActionEvent evt) {
		new today().setVisible(true);
		this.dispose();
	}

	private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {
		new manager().setVisible(true);
		this.dispose();
	}

	private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {
		new history5().setVisible(true);
		this.dispose();
	}

	/**
	 * @param args the command line arguments
	 */
	public static void main(String args[]) {
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				new history().setVisible(true);
			}
		});
	}

	//GEN-BEGIN:variables
	// Variables declaration - do not modify
	private java.awt.Canvas canvas1;
	private javax.swing.JButton jButton1;
	private javax.swing.JButton jButton10;
	private javax.swing.JButton jButton11;
	private javax.swing.JButton jButton12;
	private javax.swing.JButton jButton13;
	private javax.swing.JButton jButton14;
	private javax.swing.JButton jButton15;
	private javax.swing.JButton jButton16;
	private javax.swing.JButton jButton17;
	private javax.swing.JButton jButton18;
	private javax.swing.JButton jButton19;
	private javax.swing.JButton jButton20;
	private javax.swing.JButton jButton21;
	private javax.swing.JButton jButton22;
	private javax.swing.JButton jButton23;
	private javax.swing.JButton jButton24;
	private javax.swing.JButton jButton25;
	private javax.swing.JButton jButton26;
	private javax.swing.JButton jButton27;
	private javax.swing.JButton jButton28;
	private javax.swing.JButton jButton29;
	private javax.swing.JButton jButton30;
	private javax.swing.JButton jButton31;
	private javax.swing.JButton jButton32;
	private javax.swing.JButton jButton33;
	private javax.swing.JButton jButton34;
	private javax.swing.JButton jButton35;
	private javax.swing.JButton jButton36;
	private javax.swing.JButton jButton37;
	private javax.swing.JButton jButton38;
	private javax.swing.JButton jButton39;
	private javax.swing.JButton jButton40;
	private javax.swing.JButton jButton41;
	private javax.swing.JButton jButton42;
	private javax.swing.JButton jButton43;
	private javax.swing.JButton jButton44;
	private javax.swing.JButton jButton45;
	private javax.swing.JButton jButton46;
	private javax.swing.JButton jButton47;
	private javax.swing.JButton jButton48;
	private javax.swing.JButton jButton49;
	private javax.swing.JButton jButton50;
	private javax.swing.JButton jButton51;
	private javax.swing.JButton jButton52;
	private javax.swing.JButton jButton53;
	private javax.swing.JButton jButton6;
	private javax.swing.JButton jButton7;
	private javax.swing.JButton jButton8;
	private javax.swing.JButton jButton9;
	private javax.swing.JLabel jLabel1;
	private javax.swing.JLabel jLabel12;
	private javax.swing.JLabel jLabel13;
	private javax.swing.JLabel jLabel14;
	private javax.swing.JLabel jLabel15;
	private javax.swing.JLabel jLabel16;
	private javax.swing.JLabel jLabel17;
	private javax.swing.JLabel jLabel18;
	private javax.swing.JLabel jLabel20;
	private javax.swing.JLabel jLabel22;
	private javax.swing.JLabel jLabel25;
	private javax.swing.JLabel jLabel30;
	private javax.swing.JLabel jLabel4;
	private javax.swing.JLabel jLabel5;
	private javax.swing.JLabel jLabel6;
	private javax.swing.JPanel jPanel1;
	private javax.swing.JPanel jPanel2;
	private javax.swing.JPanel jPanel4;
	// End of variables declaration//GEN-END:variables

}