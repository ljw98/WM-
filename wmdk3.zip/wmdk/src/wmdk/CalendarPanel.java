package wmdk;



import java.awt.BorderLayout;
import java.awt.Container;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Calendar;
import java.util.GregorianCalendar;
import javax.swing.AbstractButton;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class CalendarPanel extends JFrame {

	private static final long serialVersionUID = 1L;
	Calendar cal = null;
	JPanel operationPanel = null;
	JPanel dateContainerPanel = null;
	
	JButton pMonth = new JButton("<");
	JButton nMonth = new JButton(">");
	JButton pYear = new JButton("<<");
	JButton nYear = new JButton(">>");
	JButton sure = new JButton("ȷ��");
	JLabel monthLabel = new JLabel();

	private int year;
	private int month;
	private int day;
	public CalendarPanel() {
		Calendar cal = Calendar.getInstance();
		this.year = cal.get(Calendar.YEAR);
		this.month = cal.get(Calendar.MONTH);
		this.day=cal.get(Calendar.DATE);
		buildJFrame(cal);
	}

	public void buildJFrame(Calendar cal) {
		Container contentPane = getContentPane();
		contentPane.add(getOprPanel(), BorderLayout.NORTH);
		contentPane.add(getPanel(cal), BorderLayout.CENTER);
		setSize(500, 500);
		setVisible(true);
		setLocationRelativeTo(null);
//		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	public static void main(String args[]) {
		new CalendarPanel();
	}

	// ������ť���·���ʾ
	public JPanel getOprPanel() {
		if (operationPanel == null) {
			operationPanel = new JPanel();
		}
		Box hBox = Box.createHorizontalBox();
		monthLabel.setText(this.year + "�� " + (this.month + 1) + "��"+this.day+"��");
		hBox.add(sure);
		hBox.add(pYear);
		hBox.add(Box.createHorizontalStrut(20));
		hBox.add(pMonth);
		hBox.add(Box.createHorizontalStrut(20));
		hBox.add(monthLabel);
		hBox.add(Box.createHorizontalStrut(20));
		hBox.add(nMonth);
		hBox.add(Box.createHorizontalStrut(20));
		hBox.add(nYear);
		pYear.addActionListener(new previousYear());
		nYear.addActionListener(new nextYear());
		pMonth.addActionListener(new previousMonth());
		nMonth.addActionListener(new nextMonth());
		sure.addActionListener(new chooseFrame());
		operationPanel.add(hBox);
		return operationPanel;
	}

	// �����������
	public JPanel getPanel(Calendar cal) {
		if (dateContainerPanel == null) {
			dateContainerPanel = new JPanel();
		}
		dateContainerPanel.removeAll();
		cal.set(Calendar.DAY_OF_MONTH, 1);
		cal.add(Calendar.MONTH, 1);
		cal.add(Calendar.DAY_OF_MONTH, -1);
		int weeks = cal.get(Calendar.WEEK_OF_MONTH);

		GridLayout grid = new GridLayout(weeks + 1, 7);
		dateContainerPanel.setLayout(grid);
		cal.set(Calendar.DAY_OF_MONTH, 1);
		int weekday = cal.get(Calendar.DAY_OF_WEEK);
		cal.add(Calendar.DAY_OF_MONTH, 1 - weekday);

		String[] weekTitle = { "��", "һ", "��", "��", "��", "��", "��" };

		// �����·���������
		
		for (int i = 0; i < weeks + 1; i++) {
			for (int j = 0; j < 7; j++) {
				if (i == 0) {
					JButton button = new JButton(weekTitle[j]);
					button.setEnabled(false);
					dateContainerPanel.add(button);
				} else {
					JButton button = new JButton(String.valueOf(cal.get(Calendar.DAY_OF_MONTH)));
					if (cal.get(Calendar.MONTH) != month) {
						button.setEnabled(false);
					}
					button.addActionListener(new chooseDay());
					dateContainerPanel.add(button);
					
					cal.add(Calendar.DAY_OF_MONTH, 1);
				}
			}
		}
		return dateContainerPanel;
	}

	// ���һ��
	class nextMonth implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			Calendar cal = new GregorianCalendar(year, month, 1);
			cal.add(Calendar.MONTH, 1);
			year = cal.get(Calendar.YEAR);
			month = cal.get(Calendar.MONTH);
			monthLabel.setText(year + "�� " + (month + 1) + "��"+"��");
			getPanel(cal);
		}
	}

	// ��ǰ��һ��
	class previousMonth implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			Calendar cal = new GregorianCalendar(year, month, 1);
			cal.add(Calendar.MONTH, -1);
			year = cal.get(Calendar.YEAR);
			month = cal.get(Calendar.MONTH);
			monthLabel.setText(year + "�� " + (month + 1) + "��"+"��");
			getPanel(cal);
		}
	}

	// ���һ��
	class nextYear implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			Calendar cal = new GregorianCalendar(year, month, 1);
			cal.add(Calendar.YEAR, 1);
			year = cal.get(Calendar.YEAR);
			month = cal.get(Calendar.MONTH);
			monthLabel.setText(year + "�� " + (month + 1) + "��"+"��");
			getPanel(cal);
		}
	}

	// ��ǰ��һ��
	class previousYear implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			Calendar cal = new GregorianCalendar(year, month, 1);
			cal.add(Calendar.YEAR, -1);
			year = cal.get(Calendar.YEAR);
			month = cal.get(Calendar.MONTH);
			monthLabel.setText(year + "�� " + (month + 1) + "��"+"��");
			getPanel(cal);
		}
	}
	class chooseDay implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			 day=Integer.parseInt(((AbstractButton) e.getSource()).getText());
			monthLabel.setText(year + "�� " + (month + 1) + "��"+day+"��");
		}
		
	}
	class chooseFrame implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			System.exit(0);
		}
		
	}
		
	}
	


