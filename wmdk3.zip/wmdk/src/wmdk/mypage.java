/*
 * mypage.java
 *
 * Created on __DATE__, __TIME__
 */

package wmdk;

import java.util.Calendar;

import javax.swing.JButton;
import javax.swing.JLabel;
import java.util.Date;
import java.util.Calendar;

import java.text.SimpleDateFormat;

/**
 *
 * @author  __USER__
 */
public class mypage extends javax.swing.JFrame {

	/** Creates new form mypage */
	public mypage() {
		initComponents();
		JButton[] buttons = { this.jButton6, this.jButton7, this.jButton8,
				this.jButton9, this.jButton10, this.jButton11, this.jButton12,
				this.jButton13, this.jButton14, this.jButton15, this.jButton16,
				this.jButton17, this.jButton18, this.jButton19, this.jButton20,
				this.jButton21, this.jButton22, this.jButton23, this.jButton24,
				this.jButton25, this.jButton26, this.jButton27, this.jButton28,
				this.jButton29, this.jButton30, this.jButton31, this.jButton32,
				this.jButton33, this.jButton34, this.jButton35, this.jButton36,
				this.jButton37, this.jButton38, this.jButton39, this.jButton40,
				this.jButton41, this.jButton42, this.jButton43, this.jButton44,
				this.jButton45, this.jButton46, this.jButton47, };
		

		Calendar c = Calendar.getInstance();
		int year = c.get(Calendar.YEAR);
		int month = c.get(Calendar.MONTH);
	    int weekday = c.get(Calendar.DAY_OF_WEEK);		
		int days=c.getActualMaximum(Calendar.DAY_OF_MONTH);
		this.jLabel30.setText(year + "�� " + (month + 1) + "��");
		
         int start = 7 - weekday;
		//�������һ��
	      int currentMonth = month;
	     c.set(c.get(Calendar.YEAR), currentMonth, 1);
	     c.add(Calendar.DATE, -1);
	     int nextmonth = c.get(Calendar.DAY_OF_MONTH);
	   
		LoadDay(buttons, nextmonth-start+1, start, days+1);
	}
//������ȡ��һ����Щ����
	void LoadDay(JButton[] buttons, int start, int gap, int days) {

		int i = 0;
		for (; i < 42 && i < gap; i++) {
			//			System.out.println(i);
			buttons[i].setText(start + i + "");
			buttons[i].setEnabled(false);
		}
		for (int j = 1; i < 42 && j < days; i++, j++) {
			buttons[i].setText(j + "");

		}
		for (int j = 1; i < 42; i++, j++) {
			buttons[i].setText(j + "");
			buttons[i].setEnabled(false);
		}
	}

	//GEN-BEGIN:initComponents
	// <editor-fold defaultstate="collapsed" desc="Generated Code">
	private void initComponents() {

		jPanel1 = new javax.swing.JPanel();
		jButton1 = new javax.swing.JButton();
		jPanel2 = new javax.swing.JPanel();
		jButton5 = new javax.swing.JButton();
		jLabel2 = new javax.swing.JLabel();
		jLabel3 = new javax.swing.JLabel();
		jButton4 = new javax.swing.JButton();
		canvas1 = new java.awt.Canvas();
		jLabel1 = new javax.swing.JLabel();
		jLabel13 = new javax.swing.JLabel();
		jLabel14 = new javax.swing.JLabel();
		jLabel15 = new javax.swing.JLabel();
		jLabel16 = new javax.swing.JLabel();
		jLabel17 = new javax.swing.JLabel();
		jButton6 = new javax.swing.JButton();
		jButton7 = new javax.swing.JButton();
		jButton8 = new javax.swing.JButton();
		jButton9 = new javax.swing.JButton();
		jButton10 = new javax.swing.JButton();
		jButton11 = new javax.swing.JButton();
		jButton12 = new javax.swing.JButton();
		jButton13 = new javax.swing.JButton();
		jButton14 = new javax.swing.JButton();
		jButton15 = new javax.swing.JButton();
		jButton16 = new javax.swing.JButton();
		jButton17 = new javax.swing.JButton();
		jButton18 = new javax.swing.JButton();
		jButton19 = new javax.swing.JButton();
		jButton20 = new javax.swing.JButton();
		jButton21 = new javax.swing.JButton();
		jButton22 = new javax.swing.JButton();
		jButton23 = new javax.swing.JButton();
		jButton24 = new javax.swing.JButton();
		jButton25 = new javax.swing.JButton();
		jButton26 = new javax.swing.JButton();
		jButton27 = new javax.swing.JButton();
		jButton28 = new javax.swing.JButton();
		jButton29 = new javax.swing.JButton();
		jButton30 = new javax.swing.JButton();
		jButton31 = new javax.swing.JButton();
		jButton32 = new javax.swing.JButton();
		jButton33 = new javax.swing.JButton();
		jButton34 = new javax.swing.JButton();
		jButton35 = new javax.swing.JButton();
		jButton36 = new javax.swing.JButton();
		jButton37 = new javax.swing.JButton();
		jButton38 = new javax.swing.JButton();
		jButton39 = new javax.swing.JButton();
		jButton40 = new javax.swing.JButton();
		jButton41 = new javax.swing.JButton();
		jButton42 = new javax.swing.JButton();
		jButton43 = new javax.swing.JButton();
		jButton44 = new javax.swing.JButton();
		jButton45 = new javax.swing.JButton();
		jButton46 = new javax.swing.JButton();
		jButton47 = new javax.swing.JButton();
		jLabel18 = new javax.swing.JLabel();
		jLabel19 = new javax.swing.JLabel();
		jLabel20 = new javax.swing.JLabel();
		jLabel21 = new javax.swing.JLabel();
		jLabel22 = new javax.swing.JLabel();
		jLabel23 = new javax.swing.JLabel();
		jLabel24 = new javax.swing.JLabel();
		jLabel25 = new javax.swing.JLabel();
		jLabel26 = new javax.swing.JLabel();
		jLabel27 = new javax.swing.JLabel();
		jLabel28 = new javax.swing.JLabel();
		jLabel29 = new javax.swing.JLabel();
		jLabel30 = new javax.swing.JLabel();
		jPanel4 = new javax.swing.JPanel();
		jButton2 = new javax.swing.JButton();
		jButton3 = new javax.swing.JButton();
		jLabel4 = new javax.swing.JLabel();
		jLabel5 = new javax.swing.JLabel();
		jLabel6 = new javax.swing.JLabel();
		jLabel7 = new javax.swing.JLabel();
		jLabel8 = new javax.swing.JLabel();
		jLabel9 = new javax.swing.JLabel();
		jLabel10 = new javax.swing.JLabel();
		jLabel11 = new javax.swing.JLabel();

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

		jPanel1.setBackground(new java.awt.Color(237, 220, 215));

		jButton1.setBackground(new java.awt.Color(237, 220, 215));
		jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/dd_nav_back_nor_2x.png"))); // NOI18N
		jButton1.setBorder(null);
		jButton1.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton1ActionPerformed(evt);
			}
		});

		jPanel2.setBackground(new java.awt.Color(255, 255, 255));

		jButton5.setBackground(new java.awt.Color(255, 255, 255));
		jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/boy-1.png"))); // NOI18N
		jButton5.setBorder(null);
		jButton5.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton5ActionPerformed(evt);
			}
		});

		jLabel2.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
		jLabel2.setText("\u51c6\u65f6\u6b21\u6570\uff1a");

		jLabel3.setFont(new java.awt.Font("Microsoft YaHei UI", 1, 22));
		jLabel3.setText("0\u6b21");

		jButton4.setBackground(new java.awt.Color(24, 28, 24));
		jButton4.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
		jButton4.setForeground(new java.awt.Color(255, 255, 255));
		jButton4.setText("HEIZICAO");
		jButton4.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton4ActionPerformed(evt);
			}
		});

		jLabel1.setFont(new java.awt.Font("Microsoft YaHei UI", 1, 18));
		jLabel1.setForeground(new java.awt.Color(51, 51, 51));
		jLabel1.setText("\u65e5");

		jLabel13.setFont(new java.awt.Font("Microsoft YaHei UI", 1, 18));
		jLabel13.setForeground(new java.awt.Color(51, 51, 51));
		jLabel13.setText("\u4e00");

		jLabel14.setFont(new java.awt.Font("Microsoft YaHei UI", 1, 18));
		jLabel14.setForeground(new java.awt.Color(51, 51, 51));
		jLabel14.setText("\u4e8c");

		jLabel15.setFont(new java.awt.Font("Microsoft YaHei UI", 1, 18));
		jLabel15.setForeground(new java.awt.Color(51, 51, 51));
		jLabel15.setText("\u4e09");

		jLabel16.setFont(new java.awt.Font("Microsoft YaHei UI", 1, 18));
		jLabel16.setForeground(new java.awt.Color(51, 51, 51));
		jLabel16.setText("\u56db");

		jLabel17.setFont(new java.awt.Font("Microsoft YaHei UI", 1, 18));
		jLabel17.setForeground(new java.awt.Color(51, 51, 51));
		jLabel17.setText("\u4e94");

		jButton6.setBackground(new java.awt.Color(255, 255, 255));
		jButton6.setText("jButton6");

		jButton7.setBackground(new java.awt.Color(255, 255, 255));
		jButton7.setText("jButton6");

		jButton8.setBackground(new java.awt.Color(255, 255, 255));
		jButton8.setText("jButton6");

		jButton9.setBackground(new java.awt.Color(255, 255, 255));
		jButton9.setText("jButton6");

		jButton10.setBackground(new java.awt.Color(255, 255, 255));
		jButton10.setText("jButton6");

		jButton11.setBackground(new java.awt.Color(255, 255, 255));
		jButton11.setText("jButton6");

		jButton12.setBackground(new java.awt.Color(255, 255, 255));
		jButton12.setText("jButton6");

		jButton13.setBackground(new java.awt.Color(255, 255, 255));
		jButton13.setText("jButton6");

		jButton14.setBackground(new java.awt.Color(255, 255, 255));
		jButton14.setText("jButton6");

		jButton15.setBackground(new java.awt.Color(255, 255, 255));
		jButton15.setText("jButton6");

		jButton16.setBackground(new java.awt.Color(255, 255, 255));
		jButton16.setText("jButton6");

		jButton17.setBackground(new java.awt.Color(255, 255, 255));
		jButton17.setText("jButton6");

		jButton18.setBackground(new java.awt.Color(255, 255, 255));
		jButton18.setText("jButton6");

		jButton19.setBackground(new java.awt.Color(255, 255, 255));
		jButton19.setText("jButton6");

		jButton20.setBackground(new java.awt.Color(255, 255, 255));
		jButton20.setText("jButton6");

		jButton21.setBackground(new java.awt.Color(255, 255, 255));
		jButton21.setText("jButton6");

		jButton22.setBackground(new java.awt.Color(255, 255, 255));
		jButton22.setText("jButton6");

		jButton23.setBackground(new java.awt.Color(255, 255, 255));
		jButton23.setText("jButton6");

		jButton24.setBackground(new java.awt.Color(255, 255, 255));
		jButton24.setText("jButton6");

		jButton25.setBackground(new java.awt.Color(255, 255, 255));
		jButton25.setText("jButton6");

		jButton26.setBackground(new java.awt.Color(255, 255, 255));
		jButton26.setText("jButton6");

		jButton27.setBackground(new java.awt.Color(255, 255, 255));
		jButton27.setText("jButton6");

		jButton28.setBackground(new java.awt.Color(255, 255, 255));
		jButton28.setText("jButton6");

		jButton29.setBackground(new java.awt.Color(255, 255, 255));
		jButton29.setText("jButton6");

		jButton30.setBackground(new java.awt.Color(255, 255, 255));
		jButton30.setText("jButton6");

		jButton31.setBackground(new java.awt.Color(255, 255, 255));
		jButton31.setText("jButton6");

		jButton32.setBackground(new java.awt.Color(255, 255, 255));
		jButton32.setText("jButton6");

		jButton33.setBackground(new java.awt.Color(255, 255, 255));
		jButton33.setText("jButton6");

		jButton34.setBackground(new java.awt.Color(255, 255, 255));
		jButton34.setText("jButton6");

		jButton35.setBackground(new java.awt.Color(255, 255, 255));
		jButton35.setText("jButton6");

		jButton36.setBackground(new java.awt.Color(255, 255, 255));
		jButton36.setText("jButton6");

		jButton37.setBackground(new java.awt.Color(255, 255, 255));
		jButton37.setText("jButton6");

		jButton38.setBackground(new java.awt.Color(255, 255, 255));
		jButton38.setText("jButton6");

		jButton39.setBackground(new java.awt.Color(255, 255, 255));
		jButton39.setText("jButton6");

		jButton40.setBackground(new java.awt.Color(255, 255, 255));
		jButton40.setText("jButton6");

		jButton41.setBackground(new java.awt.Color(255, 255, 255));
		jButton41.setText("jButton6");

		jButton42.setBackground(new java.awt.Color(255, 255, 255));
		jButton42.setText("jButton6");

		jButton43.setBackground(new java.awt.Color(255, 255, 255));
		jButton43.setText("jButton6");

		jButton44.setBackground(new java.awt.Color(255, 255, 255));
		jButton44.setText("jButton6");

		jButton45.setBackground(new java.awt.Color(255, 255, 255));
		jButton45.setText("jButton6");

		jButton46.setBackground(new java.awt.Color(255, 255, 255));
		jButton46.setText("jButton6");

		jButton47.setBackground(new java.awt.Color(255, 255, 255));
		jButton47.setText("jButton6");

		jLabel18.setFont(new java.awt.Font("Microsoft YaHei UI", 1, 18));
		jLabel18.setForeground(new java.awt.Color(51, 51, 51));
		jLabel18.setText("\u516d");

		jLabel19.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
		jLabel19.setText("\u8fdf\u5230\u6b21\u6570\uff1a");

		jLabel20.setFont(new java.awt.Font("Microsoft YaHei UI", 1, 22));
		jLabel20.setText("0\u6b21");

		jLabel21.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
		jLabel21.setText("\u8bf7\u5047\u6b21\u6570\uff1a");

		jLabel22.setFont(new java.awt.Font("Microsoft YaHei UI", 1, 22));
		jLabel22.setText("0\u6b21");

		jLabel23.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
		jLabel23.setText("\u8865\u5361\u6b21\u6570\uff1a");

		jLabel24.setFont(new java.awt.Font("Microsoft YaHei UI", 1, 22));
		jLabel24.setText("0\u6b21");

		jLabel25.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
		jLabel25.setText("\u65e9\u9000\u6b21\u6570\uff1a");

		jLabel26.setFont(new java.awt.Font("Microsoft YaHei UI", 1, 22));
		jLabel26.setText("0\u6b21");

		jLabel27.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
		jLabel27.setText("\u672a\u5230\u6b21\u6570\uff1a");

		jLabel28.setFont(new java.awt.Font("Microsoft YaHei UI", 1, 22));
		jLabel28.setText("0\u6b21");

		jLabel29.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
		jLabel29.setText("\u5de5\u7a0b\u90e8");

		jLabel30.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 24));
		jLabel30.setForeground(new java.awt.Color(51, 51, 51));
		jLabel30.setText("2018\u5e7411\u6708");

		javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(
				jPanel2);
		jPanel2.setLayout(jPanel2Layout);
		jPanel2Layout
				.setHorizontalGroup(jPanel2Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel2Layout
										.createSequentialGroup()
										.addGroup(
												jPanel2Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addGroup(
																jPanel2Layout
																		.createSequentialGroup()
																		.addContainerGap()
																		.addComponent(
																				jButton20,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				61,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jButton21,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				61,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jButton22,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				61,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jButton23,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				61,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jButton24,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				61,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jButton25,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				61,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jButton26,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				61,
																				javax.swing.GroupLayout.PREFERRED_SIZE))
														.addGroup(
																jPanel2Layout
																		.createSequentialGroup()
																		.addContainerGap()
																		.addComponent(
																				jButton27,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				61,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jButton28,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				61,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jButton29,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				61,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jButton30,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				61,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jButton31,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				61,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jButton32,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				61,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jButton33,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				61,
																				javax.swing.GroupLayout.PREFERRED_SIZE))
														.addGroup(
																jPanel2Layout
																		.createSequentialGroup()
																		.addContainerGap()
																		.addComponent(
																				jButton34,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				61,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jButton35,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				61,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jButton36,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				61,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jButton37,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				61,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jButton38,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				61,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jButton39,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				61,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jButton40,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				61,
																				javax.swing.GroupLayout.PREFERRED_SIZE))
														.addGroup(
																jPanel2Layout
																		.createSequentialGroup()
																		.addContainerGap()
																		.addComponent(
																				jButton41,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				61,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jButton42,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				61,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jButton43,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				61,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jButton44,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				61,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jButton45,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				61,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jButton46,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				61,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jButton47,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				61,
																				javax.swing.GroupLayout.PREFERRED_SIZE))
														.addGroup(
																jPanel2Layout
																		.createSequentialGroup()
																		.addGroup(
																				jPanel2Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.TRAILING)
																						.addGroup(
																								javax.swing.GroupLayout.Alignment.LEADING,
																								jPanel2Layout
																										.createSequentialGroup()
																										.addContainerGap()
																										.addGroup(
																												jPanel2Layout
																														.createParallelGroup(
																																javax.swing.GroupLayout.Alignment.TRAILING)
																														.addGroup(
																																javax.swing.GroupLayout.Alignment.LEADING,
																																jPanel2Layout
																																		.createSequentialGroup()
																																		.addComponent(
																																				jButton13,
																																				javax.swing.GroupLayout.PREFERRED_SIZE,
																																				61,
																																				javax.swing.GroupLayout.PREFERRED_SIZE)
																																		.addPreferredGap(
																																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																																		.addComponent(
																																				jButton14,
																																				javax.swing.GroupLayout.PREFERRED_SIZE,
																																				61,
																																				javax.swing.GroupLayout.PREFERRED_SIZE)
																																		.addPreferredGap(
																																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																																		.addComponent(
																																				jButton15,
																																				javax.swing.GroupLayout.PREFERRED_SIZE,
																																				61,
																																				javax.swing.GroupLayout.PREFERRED_SIZE)
																																		.addPreferredGap(
																																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																																		.addComponent(
																																				jButton16,
																																				javax.swing.GroupLayout.PREFERRED_SIZE,
																																				61,
																																				javax.swing.GroupLayout.PREFERRED_SIZE)
																																		.addPreferredGap(
																																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																																		.addComponent(
																																				jButton17,
																																				javax.swing.GroupLayout.PREFERRED_SIZE,
																																				61,
																																				javax.swing.GroupLayout.PREFERRED_SIZE)
																																		.addPreferredGap(
																																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																																		.addComponent(
																																				jButton18,
																																				javax.swing.GroupLayout.PREFERRED_SIZE,
																																				61,
																																				javax.swing.GroupLayout.PREFERRED_SIZE)
																																		.addPreferredGap(
																																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																																		.addComponent(
																																				jButton19,
																																				javax.swing.GroupLayout.PREFERRED_SIZE,
																																				61,
																																				javax.swing.GroupLayout.PREFERRED_SIZE))
																														.addGroup(
																																javax.swing.GroupLayout.Alignment.LEADING,
																																jPanel2Layout
																																		.createSequentialGroup()
																																		.addComponent(
																																				jButton6,
																																				javax.swing.GroupLayout.PREFERRED_SIZE,
																																				61,
																																				javax.swing.GroupLayout.PREFERRED_SIZE)
																																		.addPreferredGap(
																																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																																		.addGroup(
																																				jPanel2Layout
																																						.createParallelGroup(
																																								javax.swing.GroupLayout.Alignment.LEADING)
																																						.addGroup(
																																								jPanel2Layout
																																										.createSequentialGroup()
																																										.addComponent(
																																												jButton5)
																																										.addGap(
																																												75,
																																												75,
																																												75)
																																										.addGroup(
																																												jPanel2Layout
																																														.createParallelGroup(
																																																javax.swing.GroupLayout.Alignment.LEADING)
																																														.addComponent(
																																																jLabel29)
																																														.addComponent(
																																																jButton4)))
																																						.addGroup(
																																								jPanel2Layout
																																										.createSequentialGroup()
																																										.addComponent(
																																												jButton7,
																																												javax.swing.GroupLayout.PREFERRED_SIZE,
																																												61,
																																												javax.swing.GroupLayout.PREFERRED_SIZE)
																																										.addPreferredGap(
																																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																																										.addComponent(
																																												jButton8,
																																												javax.swing.GroupLayout.PREFERRED_SIZE,
																																												61,
																																												javax.swing.GroupLayout.PREFERRED_SIZE)
																																										.addPreferredGap(
																																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																																										.addComponent(
																																												jButton9,
																																												javax.swing.GroupLayout.PREFERRED_SIZE,
																																												61,
																																												javax.swing.GroupLayout.PREFERRED_SIZE)
																																										.addPreferredGap(
																																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																																										.addComponent(
																																												jButton10,
																																												javax.swing.GroupLayout.PREFERRED_SIZE,
																																												61,
																																												javax.swing.GroupLayout.PREFERRED_SIZE)
																																										.addPreferredGap(
																																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																																										.addComponent(
																																												jButton11,
																																												javax.swing.GroupLayout.PREFERRED_SIZE,
																																												61,
																																												javax.swing.GroupLayout.PREFERRED_SIZE)
																																										.addPreferredGap(
																																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																																										.addComponent(
																																												jButton12,
																																												0,
																																												0,
																																												Short.MAX_VALUE))))))
																						.addGroup(
																								javax.swing.GroupLayout.Alignment.LEADING,
																								jPanel2Layout
																										.createSequentialGroup()
																										.addGap(
																												34,
																												34,
																												34)
																										.addGroup(
																												jPanel2Layout
																														.createParallelGroup(
																																javax.swing.GroupLayout.Alignment.LEADING)
																														.addGroup(
																																jPanel2Layout
																																		.createSequentialGroup()
																																		.addComponent(
																																				jLabel2)
																																		.addPreferredGap(
																																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																																		.addComponent(
																																				jLabel3))
																														.addGroup(
																																jPanel2Layout
																																		.createSequentialGroup()
																																		.addComponent(
																																				jLabel19)
																																		.addPreferredGap(
																																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																																		.addComponent(
																																				jLabel20))
																														.addGroup(
																																jPanel2Layout
																																		.createSequentialGroup()
																																		.addComponent(
																																				jLabel1)
																																		.addGap(
																																				55,
																																				55,
																																				55)
																																		.addComponent(
																																				jLabel13)
																																		.addGap(
																																				54,
																																				54,
																																				54)
																																		.addGroup(
																																				jPanel2Layout
																																						.createParallelGroup(
																																								javax.swing.GroupLayout.Alignment.LEADING)
																																						.addComponent(
																																								jLabel30)
																																						.addGroup(
																																								jPanel2Layout
																																										.createSequentialGroup()
																																										.addComponent(
																																												jLabel14)
																																										.addGap(
																																												52,
																																												52,
																																												52)
																																										.addComponent(
																																												jLabel15)))))
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																										.addComponent(
																												jLabel16)
																										.addGap(
																												44,
																												44,
																												44)
																										.addComponent(
																												jLabel17)
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.RELATED,
																												53,
																												Short.MAX_VALUE)
																										.addComponent(
																												jLabel18)
																										.addGap(
																												25,
																												25,
																												25)))
																		.addGap(
																				37,
																				37,
																				37)
																		.addComponent(
																				canvas1,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				17,
																				javax.swing.GroupLayout.PREFERRED_SIZE))
														.addGroup(
																jPanel2Layout
																		.createSequentialGroup()
																		.addGap(
																				196,
																				196,
																				196)
																		.addGroup(
																				jPanel2Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.LEADING)
																						.addGroup(
																								jPanel2Layout
																										.createSequentialGroup()
																										.addPreferredGap(
																												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																										.addComponent(
																												jLabel21))
																						.addGroup(
																								jPanel2Layout
																										.createSequentialGroup()
																										.addGap(
																												6,
																												6,
																												6)
																										.addComponent(
																												jLabel23)))
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addGroup(
																				jPanel2Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.LEADING)
																						.addGroup(
																								jPanel2Layout
																										.createSequentialGroup()
																										.addComponent(
																												jLabel22)
																										.addGap(
																												18,
																												18,
																												18)
																										.addComponent(
																												jLabel27))
																						.addGroup(
																								jPanel2Layout
																										.createSequentialGroup()
																										.addComponent(
																												jLabel24)
																										.addGap(
																												24,
																												24,
																												24)
																										.addComponent(
																												jLabel25)))
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addGroup(
																				jPanel2Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.LEADING)
																						.addComponent(
																								jLabel26)
																						.addComponent(
																								jLabel28))
																		.addGap(
																				6,
																				6,
																				6)))
										.addContainerGap()));
		jPanel2Layout
				.setVerticalGroup(jPanel2Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel2Layout
										.createSequentialGroup()
										.addGroup(
												jPanel2Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addGroup(
																jPanel2Layout
																		.createSequentialGroup()
																		.addGap(
																				35,
																				35,
																				35)
																		.addComponent(
																				jButton5))
														.addGroup(
																jPanel2Layout
																		.createSequentialGroup()
																		.addGap(
																				44,
																				44,
																				44)
																		.addComponent(
																				jButton4,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				40,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addComponent(
																				jLabel29)))
										.addGap(52, 52, 52)
										.addGroup(
												jPanel2Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.CENTER)
														.addComponent(jLabel2)
														.addComponent(jLabel3)
														.addComponent(jLabel21)
														.addComponent(jLabel22)
														.addComponent(jLabel27)
														.addComponent(jLabel28))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
										.addGroup(
												jPanel2Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.CENTER)
														.addComponent(jLabel19)
														.addComponent(jLabel20)
														.addComponent(jLabel23)
														.addComponent(jLabel25)
														.addComponent(jLabel24)
														.addComponent(jLabel26))
										.addGap(40, 40, 40)
										.addGroup(
												jPanel2Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addGroup(
																jPanel2Layout
																		.createSequentialGroup()
																		.addGap(
																				108,
																				108,
																				108)
																		.addComponent(
																				canvas1,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				javax.swing.GroupLayout.DEFAULT_SIZE,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addContainerGap(
																				230,
																				Short.MAX_VALUE))
														.addGroup(
																javax.swing.GroupLayout.Alignment.TRAILING,
																jPanel2Layout
																		.createSequentialGroup()
																		.addComponent(
																				jLabel30)
																		.addGap(
																				18,
																				18,
																				18)
																		.addGroup(
																				jPanel2Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.BASELINE)
																						.addComponent(
																								jLabel1)
																						.addComponent(
																								jLabel13)
																						.addComponent(
																								jLabel14)
																						.addComponent(
																								jLabel15)
																						.addComponent(
																								jLabel16)
																						.addComponent(
																								jLabel17)
																						.addComponent(
																								jLabel18))
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addGroup(
																				jPanel2Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.BASELINE)
																						.addComponent(
																								jButton6)
																						.addComponent(
																								jButton7)
																						.addComponent(
																								jButton8)
																						.addComponent(
																								jButton9)
																						.addComponent(
																								jButton10)
																						.addComponent(
																								jButton11)
																						.addComponent(
																								jButton12))
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addGroup(
																				jPanel2Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.BASELINE)
																						.addComponent(
																								jButton13)
																						.addComponent(
																								jButton14)
																						.addComponent(
																								jButton15)
																						.addComponent(
																								jButton16)
																						.addComponent(
																								jButton17)
																						.addComponent(
																								jButton18)
																						.addComponent(
																								jButton19))
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addGroup(
																				jPanel2Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.BASELINE)
																						.addComponent(
																								jButton20)
																						.addComponent(
																								jButton21)
																						.addComponent(
																								jButton22)
																						.addComponent(
																								jButton23)
																						.addComponent(
																								jButton24)
																						.addComponent(
																								jButton25)
																						.addComponent(
																								jButton26))
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addGroup(
																				jPanel2Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.BASELINE)
																						.addComponent(
																								jButton27)
																						.addComponent(
																								jButton28)
																						.addComponent(
																								jButton29)
																						.addComponent(
																								jButton30)
																						.addComponent(
																								jButton31)
																						.addComponent(
																								jButton32)
																						.addComponent(
																								jButton33))
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addGroup(
																				jPanel2Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.BASELINE)
																						.addComponent(
																								jButton34)
																						.addComponent(
																								jButton35)
																						.addComponent(
																								jButton36)
																						.addComponent(
																								jButton37)
																						.addComponent(
																								jButton38)
																						.addComponent(
																								jButton39)
																						.addComponent(
																								jButton40))
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addGroup(
																				jPanel2Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.BASELINE)
																						.addComponent(
																								jButton41)
																						.addComponent(
																								jButton42)
																						.addComponent(
																								jButton43)
																						.addComponent(
																								jButton44)
																						.addComponent(
																								jButton45)
																						.addComponent(
																								jButton46)
																						.addComponent(
																								jButton47))
																		.addGap(
																				36,
																				36,
																				36)))));

		jPanel4.setBackground(new java.awt.Color(255, 255, 255));

		jButton2.setBackground(new java.awt.Color(255, 255, 255));
		jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/9a8f33a1ee45r3ec605e0aa44e001_����.png"))); // NOI18N
		jButton2.setBorder(null);

		jButton3.setBackground(new java.awt.Color(255, 255, 255));
		jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource(
				"/img/9a8f33605e0aa44e001_����.png"))); // NOI18N
		jButton3.setBorder(null);

		jLabel4.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 20));
		jLabel4.setText("UI\u8bbe\u8ba1");

		jLabel5.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 20));
		jLabel5.setText("UI\u8bbe\u8ba1");

		jLabel6.setText("\u5e26\u4e66\u672cXXXXX");

		jLabel7.setText("\u5e26\u4e66\u672cXXXXX");

		jLabel8.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
		jLabel8.setText("8:00");

		jLabel9.setFont(new java.awt.Font("Microsoft YaHei UI", 0, 18));
		jLabel9.setText("8:00");

		jLabel10.setFont(new java.awt.Font("Microsoft YaHei UI", 1, 18));
		jLabel10.setForeground(new java.awt.Color(255, 204, 0));
		jLabel10.setText("\u51c6\u65f6");

		jLabel11.setFont(new java.awt.Font("Microsoft YaHei UI", 1, 18));
		jLabel11.setForeground(new java.awt.Color(255, 51, 51));
		jLabel11.setText("\u8fdf\u5230");

		javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(
				jPanel4);
		jPanel4.setLayout(jPanel4Layout);
		jPanel4Layout
				.setHorizontalGroup(jPanel4Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel4Layout
										.createSequentialGroup()
										.addGap(41, 41, 41)
										.addGroup(
												jPanel4Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING,
																false)
														.addGroup(
																jPanel4Layout
																		.createSequentialGroup()
																		.addComponent(
																				jButton3,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				70,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED,
																				javax.swing.GroupLayout.DEFAULT_SIZE,
																				Short.MAX_VALUE)
																		.addGroup(
																				jPanel4Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.LEADING)
																						.addComponent(
																								jLabel7)
																						.addComponent(
																								jLabel5)))
														.addGroup(
																jPanel4Layout
																		.createSequentialGroup()
																		.addComponent(
																				jButton2,
																				javax.swing.GroupLayout.PREFERRED_SIZE,
																				70,
																				javax.swing.GroupLayout.PREFERRED_SIZE)
																		.addGap(
																				35,
																				35,
																				35)
																		.addGroup(
																				jPanel4Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.LEADING)
																						.addComponent(
																								jLabel6)
																						.addComponent(
																								jLabel4))))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED,
												207, Short.MAX_VALUE)
										.addGroup(
												jPanel4Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.TRAILING)
														.addGroup(
																jPanel4Layout
																		.createParallelGroup(
																				javax.swing.GroupLayout.Alignment.LEADING)
																		.addComponent(
																				jLabel8)
																		.addComponent(
																				jLabel9))
														.addComponent(jLabel10)
														.addComponent(jLabel11))
										.addGap(45, 45, 45)));
		jPanel4Layout
				.setVerticalGroup(jPanel4Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel4Layout
										.createSequentialGroup()
										.addGap(48, 48, 48)
										.addGroup(
												jPanel4Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addComponent(jButton2)
														.addGroup(
																jPanel4Layout
																		.createSequentialGroup()
																		.addGroup(
																				jPanel4Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.BASELINE)
																						.addComponent(
																								jLabel4)
																						.addComponent(
																								jLabel8))
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addGroup(
																				jPanel4Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.BASELINE)
																						.addComponent(
																								jLabel6)
																						.addComponent(
																								jLabel10))))
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED,
												38, Short.MAX_VALUE)
										.addGroup(
												jPanel4Layout
														.createParallelGroup(
																javax.swing.GroupLayout.Alignment.LEADING)
														.addGroup(
																jPanel4Layout
																		.createSequentialGroup()
																		.addGroup(
																				jPanel4Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.BASELINE)
																						.addComponent(
																								jLabel5)
																						.addComponent(
																								jLabel9))
																		.addPreferredGap(
																				javax.swing.LayoutStyle.ComponentPlacement.RELATED)
																		.addGroup(
																				jPanel4Layout
																						.createParallelGroup(
																								javax.swing.GroupLayout.Alignment.BASELINE)
																						.addComponent(
																								jLabel7)
																						.addComponent(
																								jLabel11)))
														.addComponent(jButton3))
										.addGap(25, 25, 25)));

		javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(
				jPanel1);
		jPanel1.setLayout(jPanel1Layout);
		jPanel1Layout.setHorizontalGroup(jPanel1Layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addGroup(
				jPanel1Layout.createSequentialGroup().addGap(24, 24, 24)
						.addComponent(jButton1,
								javax.swing.GroupLayout.PREFERRED_SIZE, 38,
								javax.swing.GroupLayout.PREFERRED_SIZE))
				.addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE,
						javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
				.addGroup(
						jPanel1Layout.createSequentialGroup().addComponent(
								jPanel2,
								javax.swing.GroupLayout.PREFERRED_SIZE, 515,
								javax.swing.GroupLayout.PREFERRED_SIZE)
								.addContainerGap(
										javax.swing.GroupLayout.DEFAULT_SIZE,
										Short.MAX_VALUE)));
		jPanel1Layout
				.setVerticalGroup(jPanel1Layout
						.createParallelGroup(
								javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(
								jPanel1Layout
										.createSequentialGroup()
										.addContainerGap()
										.addComponent(
												jButton1,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												37,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(
												jPanel2,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												Short.MAX_VALUE)
										.addPreferredGap(
												javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
										.addComponent(
												jPanel4,
												javax.swing.GroupLayout.PREFERRED_SIZE,
												javax.swing.GroupLayout.DEFAULT_SIZE,
												javax.swing.GroupLayout.PREFERRED_SIZE)));

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(
				getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 516,
				javax.swing.GroupLayout.PREFERRED_SIZE));
		layout.setVerticalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE,
				javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));

		pack();
	}// </editor-fold>
	//GEN-END:initComponents

	private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {
		new mypage2().setVisible(true);
		this.dispose();
	}

	private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {
		new mypage2().setVisible(true);
		this.dispose();
	}

	private void jButton23ActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void jButton22ActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void jButton21ActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void jButton20ActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void jButton19ActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void jButton18ActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void jButton17ActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void jButton16ActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void jButton15ActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void jButton14ActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void jButton13ActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {
		new homepage().setVisible(true);
		this.dispose();
	}

	/**
	 * @param args the command line arguments
	 */
	public static void main(String args[]) {
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				new mypage().setVisible(true);
			}
		});
	}

	//GEN-BEGIN:variables
	// Variables declaration - do not modify
	private java.awt.Canvas canvas1;
	private javax.swing.JButton jButton1;
	private javax.swing.JButton jButton10;
	private javax.swing.JButton jButton11;
	private javax.swing.JButton jButton12;
	private javax.swing.JButton jButton13;
	private javax.swing.JButton jButton14;
	private javax.swing.JButton jButton15;
	private javax.swing.JButton jButton16;
	private javax.swing.JButton jButton17;
	private javax.swing.JButton jButton18;
	private javax.swing.JButton jButton19;
	private javax.swing.JButton jButton2;
	private javax.swing.JButton jButton20;
	private javax.swing.JButton jButton21;
	private javax.swing.JButton jButton22;
	private javax.swing.JButton jButton23;
	private javax.swing.JButton jButton24;
	private javax.swing.JButton jButton25;
	private javax.swing.JButton jButton26;
	private javax.swing.JButton jButton27;
	private javax.swing.JButton jButton28;
	private javax.swing.JButton jButton29;
	private javax.swing.JButton jButton3;
	private javax.swing.JButton jButton30;
	private javax.swing.JButton jButton31;
	private javax.swing.JButton jButton32;
	private javax.swing.JButton jButton33;
	private javax.swing.JButton jButton34;
	private javax.swing.JButton jButton35;
	private javax.swing.JButton jButton36;
	private javax.swing.JButton jButton37;
	private javax.swing.JButton jButton38;
	private javax.swing.JButton jButton39;
	private javax.swing.JButton jButton4;
	private javax.swing.JButton jButton40;
	private javax.swing.JButton jButton41;
	private javax.swing.JButton jButton42;
	private javax.swing.JButton jButton43;
	private javax.swing.JButton jButton44;
	private javax.swing.JButton jButton45;
	private javax.swing.JButton jButton46;
	private javax.swing.JButton jButton47;
	private javax.swing.JButton jButton5;
	private javax.swing.JButton jButton6;
	private javax.swing.JButton jButton7;
	private javax.swing.JButton jButton8;
	private javax.swing.JButton jButton9;
	private javax.swing.JLabel jLabel1;
	private javax.swing.JLabel jLabel10;
	private javax.swing.JLabel jLabel11;
	private javax.swing.JLabel jLabel13;
	private javax.swing.JLabel jLabel14;
	private javax.swing.JLabel jLabel15;
	private javax.swing.JLabel jLabel16;
	private javax.swing.JLabel jLabel17;
	private javax.swing.JLabel jLabel18;
	private javax.swing.JLabel jLabel19;
	private javax.swing.JLabel jLabel2;
	private javax.swing.JLabel jLabel20;
	private javax.swing.JLabel jLabel21;
	private javax.swing.JLabel jLabel22;
	private javax.swing.JLabel jLabel23;
	private javax.swing.JLabel jLabel24;
	private javax.swing.JLabel jLabel25;
	private javax.swing.JLabel jLabel26;
	private javax.swing.JLabel jLabel27;
	private javax.swing.JLabel jLabel28;
	private javax.swing.JLabel jLabel29;
	private javax.swing.JLabel jLabel3;
	private javax.swing.JLabel jLabel30;
	private javax.swing.JLabel jLabel4;
	private javax.swing.JLabel jLabel5;
	private javax.swing.JLabel jLabel6;
	private javax.swing.JLabel jLabel7;
	private javax.swing.JLabel jLabel8;
	private javax.swing.JLabel jLabel9;
	private javax.swing.JPanel jPanel1;
	private javax.swing.JPanel jPanel2;
	private javax.swing.JPanel jPanel4;
	// End of variables declaration//GEN-END:variables

}